/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "qcustomplot.h"

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *action;
    QAction *action_2;
    QAction *action_3;
    QWidget *centralwidget;
    QGridLayout *gridLayout;
    QGroupBox *groupBox;
    QLineEdit *lineEdit_l;
    QLabel *label;
    QLineEdit *lineEdit_F_2;
    QLabel *label_2;
    QLabel *label_3;
    QLineEdit *lineEdit_F_1;
    QLabel *label_4;
    QLineEdit *lineEdit_omega;
    QComboBox *comboBox_Material;
    QLabel *label_5;
    QLabel *label_MaterialName;
    QLineEdit *lineEdit_MaterialName;
    QLabel *label_MaterialDensity;
    QLineEdit *lineEdit_MaterialDensity;
    QLabel *label_MaterialYModule;
    QLineEdit *lineEdit_MaterialYModule;
    QLabel *label_9;
    QComboBox *comboBox_TypeOfTask;
    QLabel *label_6;
    QLineEdit *lineEdit_M;
    QPushButton *pushButton_ExampleTask;
    QPushButton *pushButton_SaveMaterial;
    QGroupBox *groupBox_2;
    QGridLayout *gridLayout_2;
    QCustomPlot *widget_Graph;
    QGroupBox *groupBox_4;
    QDoubleSpinBox *doubleSpinBox_InputDot2;
    QDoubleSpinBox *doubleSpinBox_InputDot1;
    QPushButton *pushButton_AddDot;
    QGroupBox *groupBox_3;
    QVBoxLayout *verticalLayout;
    QPushButton *pushButton_ColorChange;
    QPushButton *pushButton_Move;
    QPushButton *pushButton_Zoom;
    QPushButton *pushButton_ClearGraph;
    QPushButton *pushButton_OpenFile;
    QPushButton *pushButton_SaveImage;
    QPushButton *pushButton_SaveGraph;
    QPushButton *pushButton_PlotGraph;
    QGroupBox *groupBox_5;
    QGridLayout *gridLayout_3;
    QTextBrowser *textBrowser_Out;
    QGroupBox *groupBox_6;
    QPushButton *pushButton_Save;
    QPushButton *pushButton_Go;
    QMenuBar *menubar;
    QMenu *menu;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1013, 722);
        action = new QAction(MainWindow);
        action->setObjectName(QString::fromUtf8("action"));
        action_2 = new QAction(MainWindow);
        action_2->setObjectName(QString::fromUtf8("action_2"));
        action_3 = new QAction(MainWindow);
        action_3->setObjectName(QString::fromUtf8("action_3"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        gridLayout = new QGridLayout(centralwidget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        groupBox = new QGroupBox(centralwidget);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setMaximumSize(QSize(1667, 16777215));
        lineEdit_l = new QLineEdit(groupBox);
        lineEdit_l->setObjectName(QString::fromUtf8("lineEdit_l"));
        lineEdit_l->setGeometry(QRect(30, 90, 161, 22));
        lineEdit_l->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        label = new QLabel(groupBox);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(10, 70, 131, 16));
        lineEdit_F_2 = new QLineEdit(groupBox);
        lineEdit_F_2->setObjectName(QString::fromUtf8("lineEdit_F_2"));
        lineEdit_F_2->setGeometry(QRect(30, 150, 161, 22));
        lineEdit_F_2->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        label_2 = new QLabel(groupBox);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(10, 130, 191, 16));
        label_3 = new QLabel(groupBox);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(10, 190, 181, 16));
        lineEdit_F_1 = new QLineEdit(groupBox);
        lineEdit_F_1->setObjectName(QString::fromUtf8("lineEdit_F_1"));
        lineEdit_F_1->setGeometry(QRect(30, 210, 161, 22));
        lineEdit_F_1->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        label_4 = new QLabel(groupBox);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(10, 300, 151, 16));
        lineEdit_omega = new QLineEdit(groupBox);
        lineEdit_omega->setObjectName(QString::fromUtf8("lineEdit_omega"));
        lineEdit_omega->setGeometry(QRect(30, 320, 161, 22));
        lineEdit_omega->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        comboBox_Material = new QComboBox(groupBox);
        comboBox_Material->setObjectName(QString::fromUtf8("comboBox_Material"));
        comboBox_Material->setGeometry(QRect(30, 380, 161, 22));
        label_5 = new QLabel(groupBox);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(10, 360, 111, 16));
        label_MaterialName = new QLabel(groupBox);
        label_MaterialName->setObjectName(QString::fromUtf8("label_MaterialName"));
        label_MaterialName->setGeometry(QRect(10, 420, 151, 16));
        lineEdit_MaterialName = new QLineEdit(groupBox);
        lineEdit_MaterialName->setObjectName(QString::fromUtf8("lineEdit_MaterialName"));
        lineEdit_MaterialName->setGeometry(QRect(30, 450, 161, 22));
        lineEdit_MaterialName->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        label_MaterialDensity = new QLabel(groupBox);
        label_MaterialDensity->setObjectName(QString::fromUtf8("label_MaterialDensity"));
        label_MaterialDensity->setGeometry(QRect(10, 480, 161, 16));
        lineEdit_MaterialDensity = new QLineEdit(groupBox);
        lineEdit_MaterialDensity->setObjectName(QString::fromUtf8("lineEdit_MaterialDensity"));
        lineEdit_MaterialDensity->setGeometry(QRect(30, 500, 161, 22));
        lineEdit_MaterialDensity->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        label_MaterialYModule = new QLabel(groupBox);
        label_MaterialYModule->setObjectName(QString::fromUtf8("label_MaterialYModule"));
        label_MaterialYModule->setGeometry(QRect(10, 530, 121, 16));
        lineEdit_MaterialYModule = new QLineEdit(groupBox);
        lineEdit_MaterialYModule->setObjectName(QString::fromUtf8("lineEdit_MaterialYModule"));
        lineEdit_MaterialYModule->setGeometry(QRect(30, 550, 161, 22));
        lineEdit_MaterialYModule->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        label_9 = new QLabel(groupBox);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(10, 20, 121, 16));
        comboBox_TypeOfTask = new QComboBox(groupBox);
        comboBox_TypeOfTask->addItem(QString());
        comboBox_TypeOfTask->addItem(QString());
        comboBox_TypeOfTask->addItem(QString());
        comboBox_TypeOfTask->addItem(QString());
        comboBox_TypeOfTask->setObjectName(QString::fromUtf8("comboBox_TypeOfTask"));
        comboBox_TypeOfTask->setGeometry(QRect(30, 40, 161, 21));
        label_6 = new QLabel(groupBox);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(10, 250, 141, 16));
        lineEdit_M = new QLineEdit(groupBox);
        lineEdit_M->setObjectName(QString::fromUtf8("lineEdit_M"));
        lineEdit_M->setGeometry(QRect(30, 270, 161, 22));
        lineEdit_M->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        pushButton_ExampleTask = new QPushButton(groupBox);
        pushButton_ExampleTask->setObjectName(QString::fromUtf8("pushButton_ExampleTask"));
        pushButton_ExampleTask->setGeometry(QRect(120, 10, 121, 24));
        pushButton_SaveMaterial = new QPushButton(groupBox);
        pushButton_SaveMaterial->setObjectName(QString::fromUtf8("pushButton_SaveMaterial"));
        pushButton_SaveMaterial->setGeometry(QRect(170, 420, 21, 21));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/rec/img/addMaterial.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_SaveMaterial->setIcon(icon);

        gridLayout->addWidget(groupBox, 1, 0, 3, 1);

        groupBox_2 = new QGroupBox(centralwidget);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        gridLayout_2 = new QGridLayout(groupBox_2);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        widget_Graph = new QCustomPlot(groupBox_2);
        widget_Graph->setObjectName(QString::fromUtf8("widget_Graph"));

        gridLayout_2->addWidget(widget_Graph, 0, 0, 1, 1);


        gridLayout->addWidget(groupBox_2, 1, 1, 1, 1);

        groupBox_4 = new QGroupBox(centralwidget);
        groupBox_4->setObjectName(QString::fromUtf8("groupBox_4"));
        groupBox_4->setMaximumSize(QSize(16777215, 100));
        doubleSpinBox_InputDot2 = new QDoubleSpinBox(groupBox_4);
        doubleSpinBox_InputDot2->setObjectName(QString::fromUtf8("doubleSpinBox_InputDot2"));
        doubleSpinBox_InputDot2->setGeometry(QRect(630, 10, 62, 22));
        doubleSpinBox_InputDot1 = new QDoubleSpinBox(groupBox_4);
        doubleSpinBox_InputDot1->setObjectName(QString::fromUtf8("doubleSpinBox_InputDot1"));
        doubleSpinBox_InputDot1->setGeometry(QRect(560, 10, 62, 22));
        pushButton_AddDot = new QPushButton(groupBox_4);
        pushButton_AddDot->setObjectName(QString::fromUtf8("pushButton_AddDot"));
        pushButton_AddDot->setGeometry(QRect(700, 10, 24, 24));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/rec/img/addPoint2.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_AddDot->setIcon(icon1);

        gridLayout->addWidget(groupBox_4, 2, 1, 1, 2);

        groupBox_3 = new QGroupBox(centralwidget);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        verticalLayout = new QVBoxLayout(groupBox_3);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        pushButton_ColorChange = new QPushButton(groupBox_3);
        pushButton_ColorChange->setObjectName(QString::fromUtf8("pushButton_ColorChange"));
        pushButton_ColorChange->setMaximumSize(QSize(24, 24));

        verticalLayout->addWidget(pushButton_ColorChange);

        pushButton_Move = new QPushButton(groupBox_3);
        pushButton_Move->setObjectName(QString::fromUtf8("pushButton_Move"));
        pushButton_Move->setMaximumSize(QSize(24, 24));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/rec/img/moving2.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_Move->setIcon(icon2);
        pushButton_Move->setCheckable(true);

        verticalLayout->addWidget(pushButton_Move);

        pushButton_Zoom = new QPushButton(groupBox_3);
        pushButton_Zoom->setObjectName(QString::fromUtf8("pushButton_Zoom"));
        pushButton_Zoom->setMaximumSize(QSize(24, 24));
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/rec/img/zoom.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_Zoom->setIcon(icon3);
        pushButton_Zoom->setCheckable(true);

        verticalLayout->addWidget(pushButton_Zoom);

        pushButton_ClearGraph = new QPushButton(groupBox_3);
        pushButton_ClearGraph->setObjectName(QString::fromUtf8("pushButton_ClearGraph"));
        pushButton_ClearGraph->setMaximumSize(QSize(24, 24));
        QIcon icon4;
        icon4.addFile(QString::fromUtf8(":/rec/img/trashcan.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_ClearGraph->setIcon(icon4);

        verticalLayout->addWidget(pushButton_ClearGraph);

        pushButton_OpenFile = new QPushButton(groupBox_3);
        pushButton_OpenFile->setObjectName(QString::fromUtf8("pushButton_OpenFile"));
        pushButton_OpenFile->setMaximumSize(QSize(24, 24));
        QIcon icon5;
        icon5.addFile(QString::fromUtf8(":/rec/img/openFolder2.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_OpenFile->setIcon(icon5);

        verticalLayout->addWidget(pushButton_OpenFile);

        pushButton_SaveImage = new QPushButton(groupBox_3);
        pushButton_SaveImage->setObjectName(QString::fromUtf8("pushButton_SaveImage"));
        pushButton_SaveImage->setMaximumSize(QSize(24, 24));
        QIcon icon6;
        icon6.addFile(QString::fromUtf8(":/rec/img/image.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_SaveImage->setIcon(icon6);

        verticalLayout->addWidget(pushButton_SaveImage);

        pushButton_SaveGraph = new QPushButton(groupBox_3);
        pushButton_SaveGraph->setObjectName(QString::fromUtf8("pushButton_SaveGraph"));
        pushButton_SaveGraph->setMaximumSize(QSize(24, 24));
        QIcon icon7;
        icon7.addFile(QString::fromUtf8(":/rec/img/save.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_SaveGraph->setIcon(icon7);

        verticalLayout->addWidget(pushButton_SaveGraph);

        pushButton_PlotGraph = new QPushButton(groupBox_3);
        pushButton_PlotGraph->setObjectName(QString::fromUtf8("pushButton_PlotGraph"));
        pushButton_PlotGraph->setMaximumSize(QSize(24, 24));
        QIcon icon8;
        icon8.addFile(QString::fromUtf8(":/rec/img/addGraph.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_PlotGraph->setIcon(icon8);

        verticalLayout->addWidget(pushButton_PlotGraph);


        gridLayout->addWidget(groupBox_3, 1, 2, 1, 1);

        groupBox_5 = new QGroupBox(centralwidget);
        groupBox_5->setObjectName(QString::fromUtf8("groupBox_5"));
        groupBox_5->setMaximumSize(QSize(16777215, 300));
        gridLayout_3 = new QGridLayout(groupBox_5);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        textBrowser_Out = new QTextBrowser(groupBox_5);
        textBrowser_Out->setObjectName(QString::fromUtf8("textBrowser_Out"));

        gridLayout_3->addWidget(textBrowser_Out, 0, 0, 1, 1);


        gridLayout->addWidget(groupBox_5, 3, 1, 1, 2);

        groupBox_6 = new QGroupBox(centralwidget);
        groupBox_6->setObjectName(QString::fromUtf8("groupBox_6"));
        groupBox_6->setMaximumSize(QSize(16777215, 50));
        pushButton_Save = new QPushButton(groupBox_6);
        pushButton_Save->setObjectName(QString::fromUtf8("pushButton_Save"));
        pushButton_Save->setGeometry(QRect(50, 10, 31, 31));
        QIcon icon9;
        icon9.addFile(QString::fromUtf8(":/rec/img/save_c.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_Save->setIcon(icon9);
        pushButton_Save->setIconSize(QSize(20, 20));
        pushButton_Go = new QPushButton(groupBox_6);
        pushButton_Go->setObjectName(QString::fromUtf8("pushButton_Go"));
        pushButton_Go->setGeometry(QRect(10, 10, 31, 31));
        QIcon icon10;
        icon10.addFile(QString::fromUtf8(":/rec/img/go2.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_Go->setIcon(icon10);
        pushButton_Go->setIconSize(QSize(20, 20));

        gridLayout->addWidget(groupBox_6, 0, 0, 1, 3);

        gridLayout->setRowStretch(0, 1);
        gridLayout->setRowStretch(1, 5);
        gridLayout->setRowStretch(2, 1);
        gridLayout->setRowStretch(3, 2);
        gridLayout->setColumnStretch(0, 4);
        gridLayout->setColumnStretch(1, 11);
        gridLayout->setColumnStretch(2, 1);
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1013, 22));
        menu = new QMenu(menubar);
        menu->setObjectName(QString::fromUtf8("menu"));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        menubar->addAction(menu->menuAction());
        menu->addAction(action);
        menu->addAction(action_2);
        menu->addAction(action_3);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        action->setText(QCoreApplication::translate("MainWindow", "\320\236\321\202\320\272\321\200\321\213\321\202\321\214", nullptr));
        action_2->setText(QCoreApplication::translate("MainWindow", "\320\227\320\260\320\272\321\200\321\213\321\202\321\214", nullptr));
        action_3->setText(QCoreApplication::translate("MainWindow", "\320\232\320\273\320\270\320\272!", nullptr));
        groupBox->setTitle(QString());
        lineEdit_l->setPlaceholderText(QCoreApplication::translate("MainWindow", "\320\274", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "\320\224\320\273\320\270\320\275\320\260 \321\201\321\202\320\265\321\200\320\266\320\275\321\217", nullptr));
        lineEdit_F_2->setPlaceholderText(QCoreApplication::translate("MainWindow", "\320\274^2", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "\320\234\320\260\320\272\321\201\320\270\320\274\320\260\320\273\321\214\320\275\320\260\321\217 \320\277\320\273\320\276\321\211\320\260\320\264\321\214 F_2", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "\320\234\320\270\320\275\320\270\320\274\320\260\320\273\321\214\320\275\320\260\321\217 \320\277\320\273\320\276\321\211\320\260\320\264\321\214 F_1", nullptr));
        lineEdit_F_1->setPlaceholderText(QCoreApplication::translate("MainWindow", "\320\274^2", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "\320\247\320\260\321\201\321\202\320\276\321\202\320\260 \320\272\320\276\320\273\320\265\320\261\320\260\320\275\320\270\320\271", nullptr));
        lineEdit_omega->setPlaceholderText(QCoreApplication::translate("MainWindow", "\320\223\321\206", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "\320\234\320\260\321\202\320\265\321\200\320\270\320\260\320\273", nullptr));
        label_MaterialName->setText(QCoreApplication::translate("MainWindow", "\320\235\320\260\320\267\320\262\320\260\320\275\320\270\320\265 \320\274\320\260\321\202\320\265\321\200\320\270\320\260\320\273\320\260", nullptr));
        label_MaterialDensity->setText(QCoreApplication::translate("MainWindow", "\320\237\320\273\320\276\321\202\320\275\320\276\321\201\321\202\321\214 \320\274\320\260\321\202\320\265\321\200\320\270\320\260\320\273\320\260", nullptr));
        lineEdit_MaterialDensity->setPlaceholderText(QCoreApplication::translate("MainWindow", "\320\272\320\263/\320\274^3", nullptr));
        label_MaterialYModule->setText(QCoreApplication::translate("MainWindow", "\320\234\320\276\320\264\321\203\320\273\321\214 \320\256\320\275\320\263\320\260", nullptr));
        lineEdit_MaterialYModule->setPlaceholderText(QCoreApplication::translate("MainWindow", "\320\237\320\260", nullptr));
        label_9->setText(QCoreApplication::translate("MainWindow", "\320\242\320\270\320\277 \320\277\320\276\321\201\321\202\321\200\320\276\320\265\320\275\320\270\321\217", nullptr));
        comboBox_TypeOfTask->setItemText(0, QCoreApplication::translate("MainWindow", "\320\230\320\267 1-\320\276\320\271 \321\207\320\260\321\201\321\202\320\270 (\320\277\320\265\321\200\320\265\320\274\320\265\320\275\320\275\320\276\320\265 \321\201\320\265\321\207\320\265\320\275\320\270\320\265)", nullptr));
        comboBox_TypeOfTask->setItemText(1, QCoreApplication::translate("MainWindow", "\320\230\320\267 2-\321\205 \321\207\320\260\321\201\321\202\320\265\320\271 (\320\277\320\265\321\200\320\265\320\274\320\265\320\275\320\275\320\276\320\265 - \320\277\320\276\321\201\321\202\320\276\321\217\320\275\320\275\320\276\320\265 \321\201\320\265\321\207\320\265\320\275\320\270\320\265)", nullptr));
        comboBox_TypeOfTask->setItemText(2, QCoreApplication::translate("MainWindow", "\320\230\320\267 2-\321\205 \321\207\320\260\321\201\321\202\320\265\320\271 (\320\277\320\276\321\201\321\202\320\276\321\217\320\275\320\275\320\276\320\265 - \320\277\320\265\321\200\320\265\320\274\320\265\320\275\320\275\320\276\320\265 \321\201\320\265\321\207\320\265\320\275\320\270\320\265)", nullptr));
        comboBox_TypeOfTask->setItemText(3, QCoreApplication::translate("MainWindow", "\320\230\320\267 3-\321\205 \321\207\320\260\321\201\321\202\320\265\320\271", nullptr));

        label_6->setText(QCoreApplication::translate("MainWindow", "\320\234\320\260\321\201\321\201\320\260 \320\275\320\260 \320\272\320\276\320\275\321\206\320\265", nullptr));
        lineEdit_M->setPlaceholderText(QCoreApplication::translate("MainWindow", "\320\272\320\263", nullptr));
        pushButton_ExampleTask->setText(QCoreApplication::translate("MainWindow", "\320\242\320\265\321\201\321\202\320\276\320\262\321\213\320\265 \320\264\320\260\320\275\320\275\321\213\320\265", nullptr));
        pushButton_SaveMaterial->setText(QString());
        groupBox_2->setTitle(QString());
        groupBox_4->setTitle(QString());
#if QT_CONFIG(tooltip)
        pushButton_AddDot->setToolTip(QCoreApplication::translate("MainWindow", "\320\224\320\276\320\261\320\260\320\262\320\273\320\265\320\275\320\270\320\265 \321\202\320\276\321\207\320\272\320\270", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_AddDot->setText(QString());
        groupBox_3->setTitle(QString());
        pushButton_ColorChange->setText(QString());
#if QT_CONFIG(tooltip)
        pushButton_Move->setToolTip(QCoreApplication::translate("MainWindow", "\320\237\320\265\321\200\320\265\320\274\320\265\321\211\320\265\320\275\320\270\320\265 \320\263\321\200\320\260\321\204\320\270\320\272\320\260", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_Move->setText(QString());
#if QT_CONFIG(tooltip)
        pushButton_Zoom->setToolTip(QCoreApplication::translate("MainWindow", "\320\230\320\267\320\274\320\265\320\275\320\265\320\275\320\270\320\265 \320\274\320\260\321\201\321\210\321\202\320\260\320\261\320\260", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_Zoom->setText(QString());
#if QT_CONFIG(tooltip)
        pushButton_ClearGraph->setToolTip(QCoreApplication::translate("MainWindow", "\320\243\320\264\320\260\320\273\320\265\320\275\320\270\320\265 \320\262\321\201\320\265\321\205 \320\263\321\200\320\260\321\204\320\270\320\272\320\276\320\262", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_ClearGraph->setText(QString());
#if QT_CONFIG(tooltip)
        pushButton_OpenFile->setToolTip(QCoreApplication::translate("MainWindow", "\320\236\321\202\320\272\321\200\321\213\321\202\320\270\320\265 \321\204\320\260\320\271\320\273\320\260", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_OpenFile->setText(QString());
#if QT_CONFIG(tooltip)
        pushButton_SaveImage->setToolTip(QCoreApplication::translate("MainWindow", "\320\241\320\276\321\205\321\200\320\260\320\275\320\265\320\275\320\270\320\265 \320\270\320\267\320\276\320\261\321\200\320\260\320\266\320\265\320\275\320\270\321\217", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_SaveImage->setText(QString());
#if QT_CONFIG(tooltip)
        pushButton_SaveGraph->setToolTip(QCoreApplication::translate("MainWindow", "\320\241\320\276\321\205\321\200\320\260\320\275\320\265\320\275\320\270\320\265 \320\264\320\260\320\275\320\275\321\213\321\205", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_SaveGraph->setText(QString());
#if QT_CONFIG(tooltip)
        pushButton_PlotGraph->setToolTip(QCoreApplication::translate("MainWindow", "\320\237\320\276\321\201\321\202\321\200\320\276\320\265\320\275\320\270\320\265 \320\263\321\200\320\260\321\204\320\270\320\272\320\260", nullptr));
#endif // QT_CONFIG(tooltip)
        pushButton_PlotGraph->setText(QString());
        groupBox_5->setTitle(QString());
        groupBox_6->setTitle(QString());
        pushButton_Save->setText(QString());
        pushButton_Go->setText(QString());
        menu->setTitle(QCoreApplication::translate("MainWindow", "\320\244\320\260\320\271\320\273", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
