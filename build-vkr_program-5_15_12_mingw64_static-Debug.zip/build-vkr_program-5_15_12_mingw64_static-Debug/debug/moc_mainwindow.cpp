/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.12)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../vkr_program/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QVector>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.12. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[35];
    char stringdata0[693];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 14), // "isInputCorrect"
QT_MOC_LITERAL(2, 26, 0), // ""
QT_MOC_LITERAL(3, 27, 8), // "QString&"
QT_MOC_LITERAL(4, 36, 3), // "str"
QT_MOC_LITERAL(5, 40, 14), // "stringToNumber"
QT_MOC_LITERAL(6, 55, 18), // "str_if_not_correct"
QT_MOC_LITERAL(7, 74, 8), // "str_name"
QT_MOC_LITERAL(8, 83, 17), // "plotGraphByPoints"
QT_MOC_LITERAL(9, 101, 16), // "QVector<double>&"
QT_MOC_LITERAL(10, 118, 5), // "vec_x"
QT_MOC_LITERAL(11, 124, 5), // "vec_y"
QT_MOC_LITERAL(12, 130, 6), // "isDots"
QT_MOC_LITERAL(13, 137, 30), // "printingInformationAboutGraphs"
QT_MOC_LITERAL(14, 168, 23), // "fillingInDataFromString"
QT_MOC_LITERAL(15, 192, 11), // "OpenTxtFile"
QT_MOC_LITERAL(16, 204, 23), // "on_actionOpen_triggered"
QT_MOC_LITERAL(17, 228, 31), // "on_pushButton_PlotGraph_clicked"
QT_MOC_LITERAL(18, 260, 32), // "on_pushButton_ClearGraph_clicked"
QT_MOC_LITERAL(19, 293, 24), // "on_pushButton_Go_clicked"
QT_MOC_LITERAL(20, 318, 30), // "on_comboBox_Material_activated"
QT_MOC_LITERAL(21, 349, 5), // "index"
QT_MOC_LITERAL(22, 355, 33), // "on_pushButton_ColorChange_cli..."
QT_MOC_LITERAL(23, 389, 26), // "on_pushButton_Move_clicked"
QT_MOC_LITERAL(24, 416, 7), // "checked"
QT_MOC_LITERAL(25, 424, 32), // "on_pushButton_ClearGraph_pressed"
QT_MOC_LITERAL(26, 457, 31), // "on_pushButton_SaveGraph_clicked"
QT_MOC_LITERAL(27, 489, 31), // "on_pushButton_SaveImage_clicked"
QT_MOC_LITERAL(28, 521, 30), // "on_pushButton_OpenFile_clicked"
QT_MOC_LITERAL(29, 552, 26), // "on_pushButton_Zoom_clicked"
QT_MOC_LITERAL(30, 579, 28), // "on_pushButton_AddDot_clicked"
QT_MOC_LITERAL(31, 608, 33), // "on_pushButton_ExampleTask_cli..."
QT_MOC_LITERAL(32, 642, 34), // "on_pushButton_SaveMaterial_cl..."
QT_MOC_LITERAL(33, 677, 8), // "slotForm"
QT_MOC_LITERAL(34, 686, 6) // "number"

    },
    "MainWindow\0isInputCorrect\0\0QString&\0"
    "str\0stringToNumber\0str_if_not_correct\0"
    "str_name\0plotGraphByPoints\0QVector<double>&\0"
    "vec_x\0vec_y\0isDots\0printingInformationAboutGraphs\0"
    "fillingInDataFromString\0OpenTxtFile\0"
    "on_actionOpen_triggered\0"
    "on_pushButton_PlotGraph_clicked\0"
    "on_pushButton_ClearGraph_clicked\0"
    "on_pushButton_Go_clicked\0"
    "on_comboBox_Material_activated\0index\0"
    "on_pushButton_ColorChange_clicked\0"
    "on_pushButton_Move_clicked\0checked\0"
    "on_pushButton_ClearGraph_pressed\0"
    "on_pushButton_SaveGraph_clicked\0"
    "on_pushButton_SaveImage_clicked\0"
    "on_pushButton_OpenFile_clicked\0"
    "on_pushButton_Zoom_clicked\0"
    "on_pushButton_AddDot_clicked\0"
    "on_pushButton_ExampleTask_clicked\0"
    "on_pushButton_SaveMaterial_clicked\0"
    "slotForm\0number"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      22,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,  124,    2, 0x08 /* Private */,
       5,    3,  127,    2, 0x08 /* Private */,
       8,    3,  134,    2, 0x08 /* Private */,
      13,    0,  141,    2, 0x08 /* Private */,
      14,    2,  142,    2, 0x08 /* Private */,
      15,    0,  147,    2, 0x08 /* Private */,
      16,    0,  148,    2, 0x08 /* Private */,
      17,    0,  149,    2, 0x08 /* Private */,
      18,    0,  150,    2, 0x08 /* Private */,
      19,    0,  151,    2, 0x08 /* Private */,
      20,    1,  152,    2, 0x08 /* Private */,
      22,    0,  155,    2, 0x08 /* Private */,
      23,    1,  156,    2, 0x08 /* Private */,
      25,    0,  159,    2, 0x08 /* Private */,
      26,    0,  160,    2, 0x08 /* Private */,
      27,    0,  161,    2, 0x08 /* Private */,
      28,    0,  162,    2, 0x08 /* Private */,
      29,    1,  163,    2, 0x08 /* Private */,
      30,    0,  166,    2, 0x08 /* Private */,
      31,    0,  167,    2, 0x08 /* Private */,
      32,    0,  168,    2, 0x08 /* Private */,
      33,    1,  169,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Bool, 0x80000000 | 3,    4,
    QMetaType::Double, 0x80000000 | 3, 0x80000000 | 3, QMetaType::QString,    4,    6,    7,
    QMetaType::Void, 0x80000000 | 9, 0x80000000 | 9, QMetaType::Bool,   10,   11,   12,
    QMetaType::QString,
    QMetaType::Void, 0x80000000 | 9, 0x80000000 | 3,   10,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   21,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   24,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   24,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   34,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: { bool _r = _t->isInputCorrect((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 1: { double _r = _t->stringToNumber((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])));
            if (_a[0]) *reinterpret_cast< double*>(_a[0]) = std::move(_r); }  break;
        case 2: _t->plotGraphByPoints((*reinterpret_cast< QVector<double>(*)>(_a[1])),(*reinterpret_cast< QVector<double>(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3]))); break;
        case 3: { QString _r = _t->printingInformationAboutGraphs();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 4: _t->fillingInDataFromString((*reinterpret_cast< QVector<double>(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 5: _t->OpenTxtFile(); break;
        case 6: _t->on_actionOpen_triggered(); break;
        case 7: _t->on_pushButton_PlotGraph_clicked(); break;
        case 8: _t->on_pushButton_ClearGraph_clicked(); break;
        case 9: _t->on_pushButton_Go_clicked(); break;
        case 10: _t->on_comboBox_Material_activated((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 11: _t->on_pushButton_ColorChange_clicked(); break;
        case 12: _t->on_pushButton_Move_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 13: _t->on_pushButton_ClearGraph_pressed(); break;
        case 14: _t->on_pushButton_SaveGraph_clicked(); break;
        case 15: _t->on_pushButton_SaveImage_clicked(); break;
        case 16: _t->on_pushButton_OpenFile_clicked(); break;
        case 17: _t->on_pushButton_Zoom_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 18: _t->on_pushButton_AddDot_clicked(); break;
        case 19: _t->on_pushButton_ExampleTask_clicked(); break;
        case 20: _t->on_pushButton_SaveMaterial_clicked(); break;
        case 21: _t->slotForm((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 22)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 22;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 22)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 22;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
