/********************************************************************************
** Form generated from reading UI file 'dialogchangeparam.ui'
**
** Created by: Qt User Interface Compiler version 5.15.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIALOGCHANGEPARAM_H
#define UI_DIALOGCHANGEPARAM_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QLabel>

QT_BEGIN_NAMESPACE

class Ui_DialogChangeParam
{
public:
    QDialogButtonBox *buttonBox;
    QComboBox *comboBox;
    QLabel *label;

    void setupUi(QDialog *DialogChangeParam)
    {
        if (DialogChangeParam->objectName().isEmpty())
            DialogChangeParam->setObjectName(QString::fromUtf8("DialogChangeParam"));
        DialogChangeParam->resize(400, 138);
        buttonBox = new QDialogButtonBox(DialogChangeParam);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setGeometry(QRect(40, 100, 341, 31));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        comboBox = new QComboBox(DialogChangeParam);
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->addItem(QString());
        comboBox->setObjectName(QString::fromUtf8("comboBox"));
        comboBox->setGeometry(QRect(20, 70, 201, 21));
        label = new QLabel(DialogChangeParam);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(20, 20, 511, 41));

        retranslateUi(DialogChangeParam);
        QObject::connect(buttonBox, SIGNAL(accepted()), DialogChangeParam, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), DialogChangeParam, SLOT(reject()));

        QMetaObject::connectSlotsByName(DialogChangeParam);
    } // setupUi

    void retranslateUi(QDialog *DialogChangeParam)
    {
        DialogChangeParam->setWindowTitle(QCoreApplication::translate("DialogChangeParam", "\320\230\320\267\320\274\320\265\320\275\320\265\320\275\320\270\320\265 \320\277\320\260\321\200\320\260\320\274\320\265\321\202\321\200\320\276\320\262", nullptr));
        comboBox->setItemText(0, QCoreApplication::translate("DialogChangeParam", "\320\235\320\265 \320\274\320\265\320\275\321\217\321\202\321\214 \321\202\320\265\320\272\321\203\321\211\320\270\320\265 \320\277\320\260\321\200\320\260\320\274\320\265\321\202\321\200\321\213", nullptr));
        comboBox->setItemText(1, QCoreApplication::translate("DialogChangeParam", "\320\230\320\267\320\274\320\265\320\275\320\270\321\202\321\214 \320\274\320\260\321\201\321\201\321\203 \320\270 \320\264\320\273\320\270\320\275\321\203", nullptr));
        comboBox->setItemText(2, QCoreApplication::translate("DialogChangeParam", "\320\230\320\267\320\274\320\265\320\275\320\270\321\202\321\214 \320\264\320\273\320\270\320\275\321\203 \320\270 F_2", nullptr));
        comboBox->setItemText(3, QCoreApplication::translate("DialogChangeParam", "\320\230\320\267\320\274\320\265\320\275\320\270\321\202\321\214 \320\264\320\273\320\270\320\275\321\203 \320\270 F_1", nullptr));
        comboBox->setItemText(4, QCoreApplication::translate("DialogChangeParam", "\320\230\320\267\320\274\320\265\320\275\320\270\321\202\321\214 \320\274\320\260\321\201\321\201\321\203 \320\270 F_2", nullptr));
        comboBox->setItemText(5, QCoreApplication::translate("DialogChangeParam", "\320\230\320\267\320\274\320\265\320\275\320\270\321\202\321\214 \320\274\320\260\321\201\321\201\321\203 \320\270 F_1", nullptr));

        label->setText(QCoreApplication::translate("DialogChangeParam", "<html><head/><body><p>\320\224\320\273\321\217 \321\202\320\265\320\272\321\203\321\211\320\265\320\271 \320\267\320\260\320\264\320\260\321\207\320\270 \320\275\320\265 \320\275\320\260\321\210\320\273\320\276\321\201\321\214 \321\200\320\265\321\210\320\265\320\275\320\270\320\271. </p><p>\320\230\320\267\320\274\320\265\320\275\320\270\321\202\321\214 \321\207\320\260\321\201\321\202\321\214 \320\277\320\260\321\200\320\260\320\274\320\265\321\202\321\200\320\276\320\262?</p></body></html>", nullptr));
    } // retranslateUi

};

namespace Ui {
    class DialogChangeParam: public Ui_DialogChangeParam {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIALOGCHANGEPARAM_H
